# Amon Kiplimo — Personal Portfolio Website

A responsive, single-page personal portfolio website with a creative dark theme and a photo gallery.

## Preview
Open `index.html` in a browser. Keep the `assets` folder beside it so all photos load.

## Publish for free with GitHub Pages
1. Sign in to GitHub or create an account.
2. Create a new public repository named `amon-portfolio` (or another name).
3. Upload `index.html` and the entire `assets` folder.
4. Open the repository's **Settings → Pages**.
5. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. GitHub Pages will show the public website address after publishing.

## Before publishing
- Check that the email address and phone number are correct.
- Add project examples only when you have real work to show.
- Dates, grades, employers, certifications, and specific AI training experience were not provided, so they have not been invented.
